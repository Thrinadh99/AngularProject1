export interface IEmployee {
  id: number;
  name: string;
  designation: string;
  gender: string;
  company: string;
  annualSalary: number
}