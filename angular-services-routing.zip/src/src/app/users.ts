export interface IUsers {
  userId?: number
  id: number;
  title: string;
  body: string;
}